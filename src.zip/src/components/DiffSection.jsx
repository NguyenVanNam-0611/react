// ─────────────────────────────────────────────────────────────
// DiffSection.jsx
// Renders one section block (heading + list of change rows).
//
// Pattern: each row renderer receives `change` and places
// <MetaRow> inside the LEFT .change-cell.
// The RIGHT .change-cell uses <div className="meta-spacer"> to
// keep both sides aligned.
// ─────────────────────────────────────────────────────────────
import { MetaRow, WordDiff, EmptyHint, ImgBox } from './WordDiff';
import { getCellText } from '../utils/diffHelpers';
import { CellContent, CellNode } from './CellContent';

// ────────────────────────────────────────────────────────────
// TEXT  (paragraph_* / heading_*)
// ────────────────────────────────────────────────────────────
function TextChangeRow({ change }) {
  const kind = change.change_kind || 'replace';
  const wd   = change.word_diff   || {};

  if (kind === 'delete') {
    const txt = change.left?.preview_text || change.left?.node?.content?.text || '';
    return (
      <div className={`change-row kind-${kind}`}>
        <div className="change-cell left">
          <MetaRow change={change} />
          <div className="txt">{txt || <EmptyHint>(trống)</EmptyHint>}</div>
        </div>
        <div className="change-cell right">
          <div className="meta-spacer" />
          <EmptyHint style={{ padding: 8 }}>(đã xóa)</EmptyHint>
        </div>
      </div>
    );
  }
  if (kind === 'insert') {
    const txt = change.right?.preview_text || change.right?.node?.content?.text || '';
    return (
      <div className={`change-row kind-${kind}`}>
        <div className="change-cell left">
          <MetaRow change={change} />
          <EmptyHint style={{ padding: 8 }}>(chưa tồn tại)</EmptyHint>
        </div>
        <div className="change-cell right">
          <div className="meta-spacer" />
          <div className="txt">{txt || <EmptyHint>(trống)</EmptyHint>}</div>
        </div>
      </div>
    );
  }
  return (
    <div className={`change-row kind-${kind}`}>
      <div className="change-cell left">
        <MetaRow change={change} />
        <div className="txt"><WordDiff wd={wd} side="left" /></div>
      </div>
      <div className="change-cell right">
        <div className="meta-spacer" />
        <div className="txt"><WordDiff wd={wd} side="right" /></div>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────
// IMAGE  (image_*)
// ────────────────────────────────────────────────────────────
function ImageChangeRow({ change }) {
  const kind    = change.change_kind || 'replace';
  const imgChg  = change.image_change || {};
  const leftImg = change.left_img  || imgChg.left_img  || change.left  || null;
  const rightImg= change.right_img || imgChg.right_img || change.right || null;
  const leftUrl = leftImg?.image_url  || leftImg?.image?.image_url  || null;
  const rightUrl= rightImg?.image_url || rightImg?.image?.image_url || null;

  return (
    <div className={`change-row kind-${kind}`}>
      <div className="change-cell left">
        <MetaRow change={change} />
        {leftUrl
          ? <div className="img-box"><img src={leftUrl} alt="original" /></div>
          : <div className="img-box"><div className="img-none">{kind === 'insert' ? '(chưa tồn tại)' : '(không có)'}</div></div>}
      </div>
      <div className="change-cell right">
        <div className="meta-spacer" />
        {rightUrl
          ? <div className="img-box"><img src={rightUrl} alt="modified" /></div>
          : <div className="img-box"><div className="img-none">{kind === 'delete' ? '(đã xóa)' : '(không có)'}</div></div>}
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────
// SHAPE  (shape_*)
// ────────────────────────────────────────────────────────────
function ShapeLines({ lines = [], lineClass = 'line-equal' }) {
  return (
    <div className="shape-lines">
      {lines.map((l, i) => <div key={i} className={`shape-line ${lineClass}`}>{l}</div>)}
    </div>
  );
}

function ShapeChangeRow({ change }) {
  const kind         = change.change_kind || 'replace';
  const shapeChanges = change.shape_changes || [];

  if (kind === 'insert') {
    const lines = change.right?.shape_text_lines || change.shape_text_preview || [];
    return (
      <div className={`change-row kind-${kind}`}>
        <div className="change-cell left"><MetaRow change={change} /><EmptyHint style={{ padding: 8 }}>(chưa tồn tại)</EmptyHint></div>
        <div className="change-cell right"><div className="meta-spacer" />
          {lines.length ? <ShapeLines lines={lines} lineClass="line-ins" /> : <EmptyHint style={{ padding: 8 }}>(shape trống)</EmptyHint>}
        </div>
      </div>
    );
  }
  if (kind === 'delete') {
    const lines = change.left?.shape_text_lines || change.shape_text_preview || [];
    return (
      <div className={`change-row kind-${kind}`}>
        <div className="change-cell left"><MetaRow change={change} />
          {lines.length ? <ShapeLines lines={lines} lineClass="line-del" /> : <EmptyHint style={{ padding: 8 }}>(shape trống)</EmptyHint>}
        </div>
        <div className="change-cell right"><div className="meta-spacer" /><EmptyHint style={{ padding: 8 }}>(đã xóa)</EmptyHint></div>
      </div>
    );
  }
  if (change.shape_cleared) {
    const lines = change.left?.shape_text_lines || change.shape_text_preview || [];
    return (
      <div className={`change-row kind-${kind}`}>
        <div className="change-cell left"><MetaRow change={change} />
          {lines.length ? <ShapeLines lines={lines} lineClass="line-del" /> : <EmptyHint>(trống)</EmptyHint>}
          <div className="shape-cleared-note">★ Toàn bộ nội dung đã bị xóa</div>
        </div>
        <div className="change-cell right"><div className="meta-spacer" /><EmptyHint style={{ padding: 8 }}>(shape đã được xóa nội dung)</EmptyHint></div>
      </div>
    );
  }
  if (!shapeChanges.length) {
    const lines = change.left?.shape_text_lines || [];
    const body  = lines.length
      ? <ShapeLines lines={lines} lineClass="line-equal" />
      : <EmptyHint style={{ padding: 8 }}>(trống)</EmptyHint>;
    return (
      <div className={`change-row kind-${kind}`}>
        <div className="change-cell left"><MetaRow change={change} />{body}</div>
        <div className="change-cell right"><div className="meta-spacer" />{body}</div>
      </div>
    );
  }

  const leftItems = [], rightItems = [];
  shapeChanges.forEach((sc, idx) => {
    const scType   = sc.type   || '';
    const orig     = sc.original;
    const mod      = sc.modified;
    const origText = orig?.content?.text || orig?.text || '';
    const modText  = mod?.content?.text  || mod?.text  || '';
    const nodeImgs = node => {
      if (!node) return [];
      return (node.children || [])
        .filter(ch => ch?.type === 'image')
        .map(ch => ch.image_url || ch.image?.image_url)
        .filter(Boolean);
    };

    if (scType === 'paragraph_equal') {
      leftItems.push(<div key={idx} className="shape-line line-equal">{origText}{nodeImgs(orig).map((u,i)=><ImgBox key={i} url={u} style={{marginTop:4}}/>)}</div>);
      rightItems.push(<div key={idx} className="shape-line line-equal">{modText||origText}{nodeImgs(mod).map((u,i)=><ImgBox key={i} url={u} style={{marginTop:4}}/>)}</div>);
    } else if (scType === 'paragraph_deleted') {
      leftItems.push(<div key={idx} className="shape-line line-del">{origText}{nodeImgs(orig).map((u,i)=><ImgBox key={i} url={u} style={{marginTop:4}}/>)}</div>);
    } else if (scType === 'paragraph_inserted') {
      rightItems.push(<div key={idx} className="shape-line line-ins">{modText}{nodeImgs(mod).map((u,i)=><ImgBox key={i} url={u} style={{marginTop:4}}/>)}</div>);
    } else if (scType === 'paragraph_modified') {
      const wd = sc.word_diff || {};
      leftItems.push(<div key={idx} className="shape-line line-modified"><WordDiff wd={wd} side="left" /></div>);
      rightItems.push(<div key={idx} className="shape-line line-modified"><WordDiff wd={wd} side="right" /></div>);
    }
  });

  return (
    <div className={`change-row kind-${kind}`}>
      <div className="change-cell left"><MetaRow change={change} />
        {leftItems.length ? <div className="shape-lines">{leftItems}</div> : <EmptyHint style={{ padding: 8 }}>—</EmptyHint>}
      </div>
      <div className="change-cell right"><div className="meta-spacer" />
        {rightItems.length ? <div className="shape-lines">{rightItems}</div> : <EmptyHint style={{ padding: 8 }}>—</EmptyHint>}
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────
// TABLE  (table_*)
// ────────────────────────────────────────────────────────────
function FullTable({ tableData, label, tableChanges = [], structureChanged = false }) {
  if (!tableData) return <div className="empty-hint" style={{ padding: 8 }}>(không có)</div>;
  const side  = label === 'before' ? 'left' : 'right';
  const rows  = tableData.rows || tableData.all_cells || [];
  const addedSet = new Set(), deletedSet = new Set(), modifiedSet = new Set();
  const cellChangeMap = {}, deletedColsPerRow = {}, addedColsPerRow = {};

  if (!structureChanged) {
    tableChanges.forEach(c => {
      const ri = c.row_index;
      if (c.type === 'table_row_deleted' && label === 'before') deletedSet.add(ri);
      if (c.type === 'table_row_added'   && label === 'after')  addedSet.add(ri);
      if (c.type === 'table_row_modified') modifiedSet.add(ri);
    });
    tableChanges.forEach(rc => {
      if (rc.type !== 'table_row_modified') return;
      const ri = rc.row_index;
      (rc.cell_changes || []).forEach(cc => {
        if (['table_cell_modified','table_cell_span_changed'].includes(cc.type)) {
          if (!cellChangeMap[ri]) cellChangeMap[ri] = {};
          cellChangeMap[ri][cc.col_index] = cc;
        }
        if (cc.type === 'table_cell_deleted') { if (!deletedColsPerRow[ri]) deletedColsPerRow[ri] = new Set(); deletedColsPerRow[ri].add(cc.col_index); }
        if (cc.type === 'table_cell_added')   { if (!addedColsPerRow[ri])   addedColsPerRow[ri]   = new Set(); addedColsPerRow[ri].add(cc.col_index);   }
      });
    });
  }

  return (
    <div className="tbl-wrap">
      <table className="doc-table">
        <tbody>
          {rows.map((rowData, arrayIdx) => {
            const cells = rowData.cells || rowData || [];
            const ri    = rowData.row_index != null ? Number(rowData.row_index) : arrayIdx;
            const rCls  = addedSet.has(ri) ? 'row-added' : deletedSet.has(ri) ? 'row-deleted' : modifiedSet.has(ri) ? 'row-modified' : '';
            let gridPos = 0;
            const tds = cells
              .filter(cell => { if (!cell) return false; const c = cell.col_index != null ? Number(cell.col_index) : 0; return c >= gridPos; })
              .map((cell, ci) => {
                const colIdx = cell.col_index != null ? Number(cell.col_index) : ci;
                const cSpan  = cell.col_span > 1 ? cell.col_span : undefined;
                const rSpan  = cell.row_span > 1 ? cell.row_span : undefined;
                const cc     = cellChangeMap[ri]?.[colIdx];
                const cellCls = cc ? 'cell-changed'
                  : (label === 'before' && deletedColsPerRow[ri]?.has(colIdx)) ? 'cell-deleted'
                  : (label === 'after'  && addedColsPerRow[ri]?.has(colIdx))   ? 'cell-added' : '';
                gridPos = colIdx + (cell.col_span > 1 ? Number(cell.col_span) : 1);
                return (
                  <td key={`${ri}_${colIdx}`} className={cellCls} colSpan={cSpan} rowSpan={rSpan}>
                    {cc ? <CellContent cellChange={cc} side={side} fallback={getCellText(cell)} cellNode={cell} />
                        : <CellNode    cellNode={cell} fallbackText={getCellText(cell)} />}
                  </td>
                );
              });
            return <tr key={ri} className={rCls}>{tds}</tr>;
          })}
        </tbody>
      </table>
    </div>
  );
}

function RowModifiedView({ tableChanges }) {
  return (
    <div className="sub-rows-wrap">
      {tableChanges.map((rc, idx) => {
        const type = rc.type || '';
        let L = null, R = null;

        if (type === 'table_row_modified') {
          const lCells = rc.left_display_cells  ?? rc.left_cells  ?? [];
          const rCells = rc.right_display_cells ?? rc.right_cells ?? [];
          const ccMap = {}; const delCols = new Set(); const addCols = new Set();
          (rc.cell_changes || []).forEach(cc => {
            if (['table_cell_modified','table_cell_span_changed'].includes(cc.type)) ccMap[cc.col_index] = cc;
            else if (cc.type === 'table_cell_deleted') delCols.add(cc.col_index);
            else if (cc.type === 'table_cell_added')   addCols.add(cc.col_index);
          });
          const renderCells = (cells, side) => cells.filter(c => c && c.type !== 'cell_span_continuation').map((c, i) => {
            const ci = c.col_index != null ? Number(c.col_index) : i;
            const cc = ccMap[ci];
            const chCls = cc ? ' cell-changed' : (side==='left' && delCols.has(ci)) ? ' cell-deleted' : (side==='right' && addCols.has(ci)) ? ' cell-added' : '';
            const fallback  = c.text_display ?? c.text ?? '';
            const fullCell  = cc ? (side==='left' ? cc.left_cell : cc.right_cell) : null;
            return (
              <td key={ci} className={`${chCls}${c.virtual_from_merge ? ' cell-virtual' : ''}`} colSpan={c.col_span>1?c.col_span:undefined}>
                {cc ? <CellContent cellChange={cc} side={side} fallback={fallback} cellNode={fullCell||c} />
                    : <CellNode cellNode={c} fallbackText={fallback} />}
              </td>
            );
          });
          L = (<><div className="tbl-label" style={{color:'#b45309'}}>≈ Dòng sửa (gốc)</div><div className="tbl-wrap"><table className="doc-table"><tbody><tr>{renderCells(lCells,'left')}</tr></tbody></table></div></>);
          R = (<><div className="tbl-label" style={{color:'#16a34a'}}>≈ Dòng sửa (mới)</div><div className="tbl-wrap"><table className="doc-table"><tbody><tr>{renderCells(rCells,'right')}</tr></tbody></table></div></>);
        }

        else if (type === 'table_row_added') {
          const cells = rc.right_display_cells ?? rc.right_cells ?? [];
          R = (<><div className="tbl-label" style={{color:'#16a34a'}}>+ Dòng mới</div><div className="tbl-wrap"><table className="doc-table"><tbody><tr className="row-added">{cells.filter(c=>c&&c.type!=='cell_span_continuation').map((c,i)=><td key={i} colSpan={c.col_span>1?c.col_span:undefined}><CellNode cellNode={c} fallbackText="" /></td>)}</tr></tbody></table></div></>);
        }

        else if (type === 'table_row_deleted') {
          const cells = rc.left_display_cells ?? rc.left_cells ?? [];
          L = (<><div className="tbl-label" style={{color:'#dc2626'}}>- Dòng xóa</div><div className="tbl-wrap"><table className="doc-table"><tbody><tr className="row-deleted">{cells.filter(c=>c&&c.type!=='cell_span_continuation').map((c,i)=><td key={i} colSpan={c.col_span>1?c.col_span:undefined}><CellNode cellNode={c} fallbackText="" /></td>)}</tr></tbody></table></div></>);
        }

        else if (type === 'table_row_merged') {
          const mergedFrom = rc.merged_from_rows || [];
          const rCells     = rc.right_display_cells ?? rc.right_cells ?? [];
          L = (<><div className="tbl-label" style={{color:'#b45309'}}>⊕ Gộp ({rc.merged_from_count||mergedFrom.length} → 1)</div><div className="tbl-wrap"><table className="doc-table"><tbody>{mergedFrom.map((r,ri)=><tr key={ri} className="row-deleted">{(r.cells||[]).map((c,ci)=><td key={ci} colSpan={c?.col_span>1?c.col_span:undefined}><CellNode cellNode={c} fallbackText="" /></td>)}</tr>)}</tbody></table></div></>);
          R = (<><div className="tbl-label" style={{color:'#16a34a'}}>⊕ Sau khi gộp</div><div className="tbl-wrap"><table className="doc-table"><tbody><tr className="row-modified">{rCells.filter(c=>c&&c.type!=='cell_span_continuation').map((c,i)=>{const ci=c.col_index??i;const cc=(rc.cell_changes||[]).find(x=>x.col_index===ci);return(<td key={i} className={c.virtual_from_merge?'cell-virtual':''} colSpan={c.col_span>1?c.col_span:undefined}>{cc?<CellContent cellChange={cc} side="right" fallback={getCellText(c)} cellNode={c}/>:<CellNode cellNode={c} fallbackText=""/>}</td>);})}</tr></tbody></table></div></>);
        }

        return (
          <div key={idx} className="sub-row">
            <div className="sub-cell sub-left">{L}</div>
            <div className="sub-cell">{R}</div>
          </div>
        );
      })}
    </div>
  );
}

function TableChangeRow({ change }) {
  const analysis     = change.table_analysis || {};
  const tableChanges = change.table_changes  || [];
  const renderMode   = analysis.render_mode  || 'full_table';
  const kind         = change.change_kind    || 'replace';
  const structChanged = !!analysis.structure_changed;

  const isSubRows = kind !== 'delete' && kind !== 'insert' &&
    !['full_table','row_added','table_deleted'].includes(renderMode);

  if (isSubRows) {
    return (
      <div className={`change-row kind-${kind}`} style={{ display: 'block' }}>
        <div style={{ padding: '10px 12px 4px' }}><MetaRow change={change} /></div>
        <RowModifiedView tableChanges={tableChanges} />
      </div>
    );
  }

  if (kind === 'delete' || renderMode === 'table_deleted') {
    return (
      <div className={`change-row kind-${kind}`}>
        <div className="change-cell left"><MetaRow change={change} /><div className="tbl-side-wrap"><FullTable tableData={analysis.full_table_original} label="before" /></div></div>
        <div className="change-cell right"><div className="meta-spacer" /><EmptyHint style={{ padding: 10 }}>(đã xóa)</EmptyHint></div>
      </div>
    );
  }
  if (kind === 'insert') {
    return (
      <div className={`change-row kind-${kind}`}>
        <div className="change-cell left"><MetaRow change={change} /><EmptyHint style={{ padding: 10 }}>(chưa tồn tại)</EmptyHint></div>
        <div className="change-cell right"><div className="meta-spacer" /><div className="tbl-side-wrap"><FullTable tableData={analysis.full_table_modified} label="after" /></div></div>
      </div>
    );
  }
  if (renderMode === 'full_table') {
    return (
      <div className={`change-row kind-${kind}`}>
        <div className="change-cell left"><MetaRow change={change} /><div className="tbl-side-wrap"><FullTable tableData={analysis.full_table_original} label="before" tableChanges={tableChanges} structureChanged={structChanged} /></div></div>
        <div className="change-cell right"><div className="meta-spacer" /><div className="tbl-side-wrap"><FullTable tableData={analysis.full_table_modified} label="after" tableChanges={tableChanges} structureChanged={structChanged} /></div></div>
      </div>
    );
  }
  if (renderMode === 'row_added') {
    const headerRow = analysis.header_row;
    const addedRows = analysis.added_rows || [];
    return (
      <div className={`change-row kind-${kind}`}>
        <div className="change-cell left"><MetaRow change={change} /><EmptyHint style={{ padding: 8 }}>Không có dòng mới ở bên gốc.</EmptyHint></div>
        <div className="change-cell right"><div className="meta-spacer" />
          <div className="tbl-side-wrap">
            <div className="tbl-label" style={{ color: '#16a34a' }}>▼ Dòng được thêm</div>
            <div className="tbl-wrap"><table className="doc-table"><tbody>
              {headerRow && <tr>{(headerRow.cells||[]).map((c,i)=><th key={i}>{getCellText(c)}</th>)}</tr>}
              {addedRows.map((r, ri) => {
                const cells = r.right_display_cells ?? r.right_cells ?? r.right_row?.cells ?? [];
                return (
                  <tr key={ri} className="row-added">
                    {cells.filter(c=>c&&c.type!=='cell_span_continuation').map((c,ci) => (
                      <td key={ci} className={c.virtual_from_merge?'cell-virtual':''} colSpan={c.col_span>1?c.col_span:undefined}><CellNode cellNode={c} fallbackText="" /></td>
                    ))}
                  </tr>
                );
              })}
            </tbody></table></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`change-row kind-${kind}`}>
      <div className="change-cell left"><MetaRow change={change} /></div>
      <div className="change-cell right"><div className="meta-spacer" /></div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────
// SECTION
// ────────────────────────────────────────────────────────────
export function DiffSection({ section }) {
  const heading = section.heading || '(No heading)';
  const changes = section.changes || [];

  return (
    <div className="section-block">
      <div className="section-head">
        <div className="section-head-cell">{heading}</div>
        <div className="section-head-cell">{heading}</div>
      </div>
      <div className="col-labels">
        <div className="col-label">Original</div>
        <div className="col-label">Modified</div>
      </div>
      {changes.map(change => {
        const t = change.type || '';
        if (t.startsWith('image_'))                                      return <ImageChangeRow  key={change.id} change={change} />;
        if (t.startsWith('table_'))                                      return <TableChangeRow  key={change.id} change={change} />;
        if (t.startsWith('shape_'))                                      return <ShapeChangeRow  key={change.id} change={change} />;
        if (t.startsWith('paragraph_') || t.startsWith('heading_'))     return <TextChangeRow   key={change.id} change={change} />;
        // Generic fallback
        const lTxt = change.left?.preview_text  || change.left?.node?.content?.text  || '';
        const rTxt = change.right?.preview_text || change.right?.node?.content?.text || '';
        return (
          <div key={change.id} className={`change-row kind-${change.change_kind || 'replace'}`}>
            <div className="change-cell left"><MetaRow change={change} /><div className="txt">{lTxt}</div></div>
            <div className="change-cell right"><div className="meta-spacer" /><div className="txt">{rTxt}</div></div>
          </div>
        );
      })}
    </div>
  );
}
