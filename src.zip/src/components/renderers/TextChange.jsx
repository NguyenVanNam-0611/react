// ─────────────────────────────────────────────────────────────
// renderers/TextChange.jsx
// Handles paragraph_modified, paragraph_inserted/deleted,
// heading_modified, heading_inserted/deleted
// ─────────────────────────────────────────────────────────────
import { WordDiff, EmptyHint } from '../WordDiff';

export function TextChange({ change }) {
  const kind = change.change_kind || 'replace';

  if (kind === 'delete') {
    const txt = change.left?.preview_text || change.left?.node?.content?.text || '';
    return (
      <>
        <div className="change-cell left">
          <MetaSpacer />
          <div className="txt">{txt || <EmptyHint>(trống)</EmptyHint>}</div>
        </div>
        <div className="change-cell right">
          <div className="meta-spacer" />
          <EmptyHint style={{ padding: 8 }}>(đã xóa)</EmptyHint>
        </div>
      </>
    );
  }

  if (kind === 'insert') {
    const txt = change.right?.preview_text || change.right?.node?.content?.text || '';
    return (
      <>
        <div className="change-cell left">
          <MetaSpacer />
          <EmptyHint style={{ padding: 8 }}>(chưa tồn tại)</EmptyHint>
        </div>
        <div className="change-cell right">
          <div className="meta-spacer" />
          <div className="txt">{txt || <EmptyHint>(trống)</EmptyHint>}</div>
        </div>
      </>
    );
  }

  const wd = change.word_diff || {};
  return (
    <>
      <div className="change-cell left">
        <MetaSpacer />
        <div className="txt"><WordDiff wd={wd} side="left" /></div>
      </div>
      <div className="change-cell right">
        <div className="meta-spacer" />
        <div className="txt"><WordDiff wd={wd} side="right" /></div>
      </div>
    </>
  );
}

function MetaSpacer() {
  return <div className="meta-spacer" />;
}
