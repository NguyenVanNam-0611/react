// ─────────────────────────────────────────────────────────────
// renderers/ImageChange.jsx
// ─────────────────────────────────────────────────────────────

export function ImageChange({ change }) {
  const imgChange = change.image_change || {};
  const leftImg  = change.left_img  || imgChange.left_img  || change.left  || null;
  const rightImg = change.right_img || imgChange.right_img || change.right || null;
  const kind = change.change_kind || 'replace';

  // image_url is the canonical field per json_builder schema
  const leftUrl  = leftImg?.image_url  || leftImg?.image?.image_url  || null;
  const rightUrl = rightImg?.image_url || rightImg?.image?.image_url || null;

  return (
    <>
      <div className="change-cell left">
        <div className="meta-spacer" />
        {leftUrl
          ? <div className="img-box"><img src={leftUrl} alt="original" /></div>
          : <div className="img-box">
              <div className="img-none">{kind === 'insert' ? '(chưa tồn tại)' : '(không có)'}</div>
            </div>
        }
      </div>
      <div className="change-cell right">
        <div className="meta-spacer" />
        {rightUrl
          ? <div className="img-box"><img src={rightUrl} alt="modified" /></div>
          : <div className="img-box">
              <div className="img-none">{kind === 'delete' ? '(đã xóa)' : '(không có)'}</div>
            </div>
        }
      </div>
    </>
  );
}
