// ─────────────────────────────────────────────────────────────
// renderers/ShapeChange.jsx
// ─────────────────────────────────────────────────────────────
import { getCellImages } from '../../utils/diffHelpers';
import { WordDiff, ImgBox } from '../WordDiff';

function ShapeLines({ lines = [], lineClass = 'line-equal' }) {
  if (!lines.length) return null;
  return (
    <div className="shape-lines">
      {lines.map((l, i) => (
        <div key={i} className={`shape-line ${lineClass}`}>{l}</div>
      ))}
    </div>
  );
}

function ShapeEmpty({ text }) {
  return <div className="empty-hint" style={{ padding: 8 }}>{text}</div>;
}

function ShapeParaImgs({ paraNode }) {
  if (!paraNode) return null;
  const imgs = getCellImages(paraNode);
  return (
    <>
      {imgs.map((url, i) => <ImgBox key={i} url={url} style={{ marginTop: 4 }} />)}
    </>
  );
}

export function ShapeChange({ change }) {
  const kind = change.change_kind || 'replace';
  const shapeChanges = change.shape_changes || [];

  // ── Insert ────────────────────────────────────────────────
  if (kind === 'insert') {
    const lines = change.right?.shape_text_lines || change.shape_text_preview || [];
    return (
      <>
        <div className="change-cell left">
          <div className="meta-spacer" />
          <ShapeEmpty text="(chưa tồn tại)" />
        </div>
        <div className="change-cell right">
          <div className="meta-spacer" />
          {lines.length
            ? <ShapeLines lines={lines} lineClass="line-ins" />
            : <ShapeEmpty text="(shape trống)" />
          }
        </div>
      </>
    );
  }

  // ── Delete ────────────────────────────────────────────────
  if (kind === 'delete') {
    const lines = change.left?.shape_text_lines || change.shape_text_preview || [];
    return (
      <>
        <div className="change-cell left">
          <div className="meta-spacer" />
          {lines.length
            ? <ShapeLines lines={lines} lineClass="line-del" />
            : <ShapeEmpty text="(shape trống)" />
          }
        </div>
        <div className="change-cell right">
          <div className="meta-spacer" />
          <ShapeEmpty text="(đã xóa)" />
        </div>
      </>
    );
  }

  // ── Cleared ───────────────────────────────────────────────
  if (change.shape_cleared) {
    const lines = change.left?.shape_text_lines || change.shape_text_preview || [];
    return (
      <>
        <div className="change-cell left">
          <div className="meta-spacer" />
          {lines.length
            ? <ShapeLines lines={lines} lineClass="line-del" />
            : <ShapeEmpty text="(trống)" />
          }
          <div className="shape-cleared-note">★ Toàn bộ nội dung đã bị xóa</div>
        </div>
        <div className="change-cell right">
          <div className="meta-spacer" />
          <ShapeEmpty text="(shape đã được xóa nội dung)" />
        </div>
      </>
    );
  }

  // ── No specific changes (equal preview) ──────────────────
  if (!shapeChanges.length) {
    const lines = change.left?.shape_text_lines || [];
    const content = lines.length
      ? <ShapeLines lines={lines} lineClass="line-equal" />
      : <ShapeEmpty text="(trống)" />;
    return (
      <>
        <div className="change-cell left"><div className="meta-spacer" />{content}</div>
        <div className="change-cell right"><div className="meta-spacer" />{content}</div>
      </>
    );
  }

  // ── Render per-change lines ───────────────────────────────
  const leftItems = [];
  const rightItems = [];

  shapeChanges.forEach((sc, idx) => {
    const scType = sc.type || '';
    const orig = sc.original;
    const mod  = sc.modified;
    const origText = orig?.content?.text || orig?.text || '';
    const modText  = mod?.content?.text  || mod?.text  || '';

    if (scType === 'paragraph_equal') {
      leftItems.push(
        <div key={idx} className="shape-line line-equal">
          {origText}
          <ShapeParaImgs paraNode={orig} />
        </div>
      );
      rightItems.push(
        <div key={idx} className="shape-line line-equal">
          {modText || origText}
          <ShapeParaImgs paraNode={mod} />
        </div>
      );
    } else if (scType === 'paragraph_deleted') {
      leftItems.push(
        <div key={idx} className="shape-line line-del">
          {origText}
          <ShapeParaImgs paraNode={orig} />
        </div>
      );
    } else if (scType === 'paragraph_inserted') {
      rightItems.push(
        <div key={idx} className="shape-line line-ins">
          {modText}
          <ShapeParaImgs paraNode={mod} />
        </div>
      );
    } else if (scType === 'paragraph_modified') {
      const wd = sc.word_diff || {};
      leftItems.push(
        <div key={idx} className="shape-line line-modified">
          <WordDiff wd={wd} side="left" />
          <ShapeParaImgs paraNode={orig} />
        </div>
      );
      rightItems.push(
        <div key={idx} className="shape-line line-modified">
          <WordDiff wd={wd} side="right" />
          <ShapeParaImgs paraNode={mod} />
        </div>
      );
    }
  });

  return (
    <>
      <div className="change-cell left">
        <div className="meta-spacer" />
        {leftItems.length
          ? <div className="shape-lines">{leftItems}</div>
          : <ShapeEmpty text="—" />
        }
      </div>
      <div className="change-cell right">
        <div className="meta-spacer" />
        {rightItems.length
          ? <div className="shape-lines">{rightItems}</div>
          : <ShapeEmpty text="—" />
        }
      </div>
    </>
  );
}
