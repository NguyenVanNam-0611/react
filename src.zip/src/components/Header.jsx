﻿export default function Header() {
    const username = localStorage.getItem("username");

    const handleLogout = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("username");
        localStorage.removeItem("role");
        window.location.href = "/";
    };

    return (
        <header className="bg-white border-b border-gray-100 px-6 py-0 sticky top-0 z-50" style={{ boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
            <div className="max-w-[1600px] mx-auto flex items-center justify-between h-16">

                {/* LEFT — Logo + Title */}
                <div className="flex items-center gap-4">
                    <img
                        src="/logo_terumo.png"
                        alt="Logo"
                        className="h-8 w-auto object-contain"
                    />
                    <div className="h-6 w-px bg-gray-200" />
                    <div>
                        <p className="text-sm font-semibold text-slate-800 leading-tight">
                            Text Comparison Tool
                        </p>
                        <p className="text-xs text-gray-400 leading-tight">
                            Hệ thống đối soát tài liệu nội bộ
                        </p>
                    </div>
                </div>

                {/* RIGHT — User + Logout */}
                <div className="flex items-center gap-4">

                    <span className="text-sm text-gray-600">
                        Xin chào : <b className="text-slate-800">{username || "—"}</b>
                    </span>

                    <div className="h-5 w-px bg-gray-200" />

                    <button
                        onClick={handleLogout}
                        className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-red-500 transition-colors px-2 py-1 rounded-lg hover:bg-red-50"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                            <polyline points="16 17 21 12 16 7" />
                            <line x1="21" y1="12" x2="9" y2="12" />
                        </svg>
                        Đăng xuất
                    </button>

                </div>
            </div>
        </header>
    );
}