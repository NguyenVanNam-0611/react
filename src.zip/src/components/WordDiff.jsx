// ─────────────────────────────────────────────────────────────
// WordDiff.jsx
// Renders word-level diff spans for one side.
// ─────────────────────────────────────────────────────────────
import { buildWordDiffParts } from '../utils/diffHelpers';

export function WordDiff({ wd, side }) {
  const parts = buildWordDiffParts(wd, side);
  const nodes = [];
  let prevHadContent = false;

  parts.forEach((p, i) => {
    if (p.type === 'empty') {
      nodes.push(<span key={i} className="empty-hint">(trống)</span>);
      return;
    }
    if (p.type === 'newline') {
      nodes.push(<br key={i} />);
      prevHadContent = false;
      return;
    }
    const space = p.spaceBefore && prevHadContent ? ' ' : '';
    if (p.type === 'text') {
      nodes.push(<span key={i}>{space}{p.text}</span>);
    } else if (p.type === 'delete') {
      nodes.push(<span key={i} className="del-span">{space}{p.text}</span>);
    } else if (p.type === 'insert') {
      nodes.push(<span key={i} className="ins-span">{space}{p.text}</span>);
    }
    prevHadContent = true;
  });

  return <>{nodes}</>;
}

/** Simple badge */
export function Badge({ label, variant }) {
  const cls = {
    type: 'badge b-type',
    delete: 'badge b-delete',
    insert: 'badge b-insert',
    replace: 'badge b-replace',
    equal: 'badge b-equal',
  }[variant] || 'badge b-type';
  return <span className={cls}>{label}</span>;
}

/** Meta row: type badge + kind badge */
export function MetaRow({ change }) {
  const dtype = change.display_type || change.type || '';
  const kind = change.change_kind || '';
  const kindVariant = kind === 'delete' ? 'delete' : kind === 'insert' ? 'insert' : 'replace';
  return (
    <div className="meta">
      <Badge label={dtype} variant="type" />
      <Badge label={kind} variant={kindVariant} />
    </div>
  );
}

/** Inline image box */
export function ImgBox({ url, style }) {
  if (!url) return null;
  return (
    <div className="img-box" style={style}>
      <img src={url} alt="" />
    </div>
  );
}

/** Empty hint */
export function EmptyHint({ children, style }) {
  return <div className="empty-hint" style={style}>{children}</div>;
}
