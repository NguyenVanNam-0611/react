// ─────────────────────────────────────────────────────────────
// CompareResult.jsx
// ─────────────────────────────────────────────────────────────
import { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { DiffSection } from '../components/DiffSection';
import '../css/compare.css';
import api from '../api/api';

function LoadingOverlay({ status }) {
    return (
        <div id="loadingOverlay">
            <div className="loading-card">
                <div className="spinner-wrap">
                    <div className="ring ring1"><div className="ring-dot" /></div>
                    <div className="ring ring2"><div className="ring-dot" /></div>
                    <div className="ring ring3"><div className="ring-dot" /></div>
                    <div className="ring-center" />
                </div>
                <div className="loading-label">Đang so sánh tài liệu</div>
                <div className="loading-status">{status || 'Đang xử lý'}</div>
            </div>
        </div>
    );
}

function DiffHeader({ originalFile, modifiedFile, counts }) {
    return (
        <div className="header">
            <div className="file-pill original">
                <span className="pill-label">Original</span>
                <span className="pill-name">{originalFile || '—'}</span>
            </div>
            <div className="header-divider">→</div>
            <div className="file-pill modified">
                <span className="pill-label">Modified</span>
                <span className="pill-name">{modifiedFile || '—'}</span>
            </div>
            {(counts.replace + counts.insert + counts.delete) > 0 && (
                <div className="header-stats">
                    {counts.replace > 0 && <span className="stat-chip chip-replace">{counts.replace} thay thế</span>}
                    {counts.insert > 0 && <span className="stat-chip chip-insert">{counts.insert} thêm mới</span>}
                    {counts.delete > 0 && <span className="stat-chip chip-delete">{counts.delete} đã xóa</span>}
                </div>
            )}
        </div>
    );
}

function countChanges(sections = []) {
    const counts = { replace: 0, insert: 0, delete: 0 };
    sections.forEach(s => (s.changes || []).forEach(c => {
        if (counts[c.change_kind] !== undefined) counts[c.change_kind]++;
    }));
    return counts;
}

export default function CompareResult() {
    const { jobId } = useParams();

    const [phase, setPhase] = useState('loading');
    const [loadStatus, setLoadStatus] = useState('Đang xử lý');
    const [errorMsg, setErrorMsg] = useState('');
    const [originalFile, setOriginalFile] = useState('');
    const [modifiedFile, setModifiedFile] = useState('');
    const [sections, setSections] = useState([]);

    const poll = useCallback(async () => {
        try {
            const token = localStorage.getItem('token');
            const res = await fetch(`/api/compare/status/${encodeURIComponent(jobId)}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (res.status === 401) { window.location.href = '/login'; return; }
            const data = await res.json();

            if (data.status === 'done') {
                setOriginalFile(data.original_file_name || '');
                setModifiedFile(data.modified_file_name || '');
                setSections(data.compare?.sections || []);
                setPhase('done');
                return;
            }

            if (data.status === 'error') {
                setErrorMsg(data.error || 'Có lỗi xảy ra khi xử lý.');
                setPhase('error');
                return;
            }

            setLoadStatus(data.status === 'queued' ? 'Đang xếp hàng' : 'Đang xử lý');
            setTimeout(poll, 1200);
        } catch (e) {
            console.error(e);
            setLoadStatus('Không thể kết nối, thử lại');
            setTimeout(poll, 2000);
        }
    }, [jobId]);

    useEffect(() => {
        if (jobId) poll();
    }, [jobId, poll]);

    const counts = countChanges(sections);

    return (
        <div className="compare-page">
            <div className="page">
                {phase === 'loading' && <LoadingOverlay status={loadStatus} />}

                {phase === 'error' && (
                    <div className="error-bar">{errorMsg}</div>
                )}

                {phase === 'done' && (
                    <>
                        <DiffHeader
                            originalFile={originalFile}
                            modifiedFile={modifiedFile}
                            counts={counts}
                        />
                        <div id="diffRoot">
                            {sections.length === 0
                                ? <div className="empty-hint" style={{ padding: 32, textAlign: 'center' }}>Không có thay đổi nào.</div>
                                : sections.map((section, i) => (
                                    <DiffSection key={i} section={section} />
                                ))
                            }
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}
