﻿// ─────────────────────────────────────────────────────────────
// diffHelpers.js
// Shared utilities for diff rendering.
// Mirrors logic from json_builder.py / the old CSHTML script.
// ─────────────────────────────────────────────────────────────

/** HTML-escape a value */
export function esc(s) {
    if (s == null) return '';
    return String(s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

/**
 * Extract display text from a serialized cell node.
 * Priority: text_display → text → walk paragraph children → nested tables
 */
export function getCellText(c) {
    if (!c) return '';
    const direct = c.text_display ?? c.text;
    if (direct) return direct;

    const children = c.children || [];

    const paraTexts = children
        .filter(ch => ch?.type === 'paragraph')
        .map(ch => ((ch.content && (ch.content.text_display ?? ch.content.text)) || '').trim())
        .filter(Boolean);
    if (paraTexts.length) return paraTexts.join('\n');

    const tableTexts = children
        .filter(ch => ch?.type === 'table')
        .map(ch => nestedTableToText(ch))
        .filter(Boolean);
    return tableTexts.join('\n');
}

function nestedTableToText(tableNode) {
    if (!tableNode) return '';
    const rows = (tableNode.children || []).filter(r => r?.type === 'row');
    return rows
        .map(row => {
            const cells = (row.children || []).filter(c => c?.type === 'cell');
            return cells
                .map(c => (c.content && (c.content.text_display ?? c.content.text)) || '')
                .filter(Boolean)
                .join(' | ');
        })
        .filter(Boolean)
        .join('\n');
}

/**
 * Get image URLs from a cell node.
 * Uses bubble-up "images" field first, then walks children.
 */
export function getCellImages(cellNode) {
    if (!cellNode) return [];
    if (Array.isArray(cellNode.images) && cellNode.images.length) {
        return cellNode.images.filter(Boolean);
    }
    const imgs = [];
    const children = cellNode.children || [];
    for (const ch of children) {
        if (!ch) continue;
        if (ch.type === 'image') {
            const url = ch.image_url || ch.image?.image_url || ch.content?.image_url;
            if (url) imgs.push(url);
        }
        if (ch.type === 'paragraph') {
            for (const img of (ch.children || [])) {
                if (img?.type === 'image') {
                    const url = img.image_url || img.image?.image_url || img.content?.image_url;
                    if (url) imgs.push(url);
                }
            }
        }
    }
    return imgs;
}

export function getAllCellImages(cellNode) {
    if (!cellNode) return [];
    const imgs = [];
    if (Array.isArray(cellNode.images) && cellNode.images.length) {
        cellNode.images.filter(Boolean).forEach(u => imgs.push(u));
    }
    for (const ch of (cellNode.children || [])) {
        if (!ch) continue;
        if (ch.type === 'image') {
            const url = ch.image_url || ch.image?.image_url || ch.content?.image_url;
            if (url && !imgs.includes(url)) imgs.push(url);
        }
        if (ch.type === 'paragraph') {
            for (const img of (ch.children || [])) {
                if (img?.type === 'image') {
                    const url = img.image_url || img.image?.image_url || img.content?.image_url;
                    if (url && !imgs.includes(url)) imgs.push(url);
                }
            }
        }
    }
    return imgs;
}

/**
 * Render word_diff spans for one side.
 * Returns an array of React-renderable elements.
 */
export function buildWordDiffParts(wd, side) {
    if (!wd) return [{ type: 'empty' }];

    const spans = wd.spans;
    if (!spans || !Array.isArray(spans) || spans.length === 0) {
        const txt = side === 'left' ? (wd.old_full_text || '') : (wd.new_full_text || '');
        return txt ? [{ type: 'text', text: txt }] : [{ type: 'empty' }];
    }

    const parts = [];
    for (const s of spans) {
        if (s.type === 'newline') {
            parts.push({ type: 'newline', spaceBefore: false });
            continue;
        }
        if (s.type === 'delete' && side !== 'left') continue;
        if (s.type === 'insert' && side !== 'right') continue;

        const spaceBefore = s.space_before === true;
        const txt = side === 'left'
            ? (s.old_text ?? s.text ?? '')
            : (s.new_text ?? s.text ?? '');
        if (!txt && s.type !== 'replace') continue;

        if (s.type === 'equal') {
            parts.push({ type: 'text', text: txt, spaceBefore });
        } else if (s.type === 'delete') {
            parts.push({ type: 'delete', text: txt, spaceBefore });
        } else if (s.type === 'insert') {
            parts.push({ type: 'insert', text: txt, spaceBefore });
        } else if (s.type === 'replace') {
            const text = side === 'left' ? (s.old_text || '') : (s.new_text || '');
            parts.push({ type: side === 'left' ? 'delete' : 'insert', text, spaceBefore });
        }
    }
    return parts.length ? parts : [{ type: 'empty' }];
}