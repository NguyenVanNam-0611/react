﻿namespace Diff_tool.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public bool IsActive { get; set; } = true; // ✅ thêm mới
        public int RoleId { get; set; }
        public Role Role { get; set; } = null!;
    }
}