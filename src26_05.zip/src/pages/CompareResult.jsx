// ─────────────────────────────────────────────────────────────
// CompareResult.jsx
// ─────────────────────────────────────────────────────────────
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { DiffSection } from '../components/DiffSection';
import Header from '../components/Header';
import Footer from '../components/Footer';
import '../css/compare.css';

function LoadingOverlay({ status }) {
    return (
        <div id="loadingOverlay">
            <div className="loading-card">
                <div className="spinner-wrap">
                    <div className="ring ring1"><div className="ring-dot" /></div>
                    <div className="ring ring2"><div className="ring-dot" /></div>
                    <div className="ring ring3"><div className="ring-dot" /></div>
                    <div className="ring-center" />
                </div>
                <div className="loading-label">Đang so sánh tài liệu</div>
                <div className="loading-status">{status || 'Đang xử lý'}</div>
            </div>
        </div>
    );
}

function splitExt(name) {
    if (!name) return { base: '—', ext: '' };
    const dot = name.lastIndexOf('.');
    if (dot === -1) return { base: name, ext: '' };
    return { base: name.slice(0, dot), ext: name.slice(dot) };
}

function DiffHeader({ originalFile, modifiedFile, counts, onExport }) {
    const orig = splitExt(originalFile);
    const modi = splitExt(modifiedFile);

    return (
        <div className="header">
            <div className="file-pill original">
                <span className="pill-label">Original</span>
                <span className="pill-name">
                    {orig.base}
                    {orig.ext && <span className="pill-ext">{orig.ext}</span>}
                </span>
            </div>

            <div className="header-divider">→</div>

            <div className="file-pill modified">
                <span className="pill-label">Modified</span>
                <span className="pill-name">
                    {modi.base}
                    {modi.ext && <span className="pill-ext">{modi.ext}</span>}
                </span>
            </div>

            <button
                className="export-pill-btn"
                onClick={onExport}
            >
                ⬇ Export
            </button>

            {(counts.replace + counts.insert + counts.delete) > 0 && (
                <div className="header-stats">
                    {counts.replace > 0 && (
                        <span className="stat-chip chip-replace">
                            {counts.replace} thay thế
                        </span>
                    )}

                    {counts.insert > 0 && (
                        <span className="stat-chip chip-insert">
                            {counts.insert} thêm mới
                        </span>
                    )}

                    {counts.delete > 0 && (
                        <span className="stat-chip chip-delete">
                            {counts.delete} đã xóa
                        </span>
                    )}
                </div>
            )}
        </div>
    );
}

function countChanges(sections = []) {
    const counts = { replace: 0, insert: 0, delete: 0 };
    sections.forEach(s => (s.changes || []).forEach(c => {
        if (counts[c.change_kind] !== undefined) counts[c.change_kind]++;
    }));
    return counts;
}

export default function CompareResult() {
    const { jobId } = useParams();

    const [phase, setPhase] = useState('loading');
    const [loadStatus, setLoadStatus] = useState('Đang xử lý');
    const [errorMsg, setErrorMsg] = useState('');
    const [originalFile, setOriginalFile] = useState('');
    const [modifiedFile, setModifiedFile] = useState('');
    const [sections, setSections] = useState([]);

    async function handleExport() {
        try {
            const token = localStorage.getItem('token');

            const response = await fetch(
                '/api/checksheet/export',
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${token}`
                    },

                    body: JSON.stringify({
                        job_id: jobId,
                        original_file: originalFile,
                        modified_file: modifiedFile,
                        sections: sections
                    })
                }
            );

            if (!response.ok) {
                throw new Error('Export thất bại');
            }

            const blob = await response.blob();

            const url = window.URL.createObjectURL(blob);

            const a = document.createElement('a');

            a.href = url;
            a.download = `Checksheet_${jobId}.xlsx`;

            document.body.appendChild(a);

            a.click();

            a.remove();

            window.URL.revokeObjectURL(url);

        } catch (err) {
            console.error(err);
            alert('Không thể export');
        }
    }

    useEffect(() => {
        if (!jobId) return;
        let cancelled = false;

        async function doPoll() {
            try {
                const token = localStorage.getItem('token');
                const res = await fetch(`/api/compare/status/${encodeURIComponent(jobId)}`, {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (res.status === 401) { window.location.href = '/login'; return; }
                const data = await res.json();
                if (cancelled) return;

                if (data.status === 'done') {
                    setOriginalFile(data.original_file_name || '');
                    setModifiedFile(data.modified_file_name || '');
                    setSections(data.compare?.sections || []);
                    setPhase('done');
                    return;
                }

                if (data.status === 'error') {
                    setErrorMsg(data.error || 'Có lỗi xảy ra khi xử lý.');
                    setPhase('error');
                    return;
                }

                setLoadStatus(data.status === 'queued' ? 'Đang xếp hàng' : 'Đang xử lý');
                setTimeout(doPoll, 1200);
            } catch (e) {
                console.error(e);
                if (!cancelled) {
                    setLoadStatus('Không thể kết nối, thử lại');
                    setTimeout(doPoll, 2000);
                }
            }
        }

        doPoll();
        return () => { cancelled = true; };
    }, [jobId]);

    const counts = countChanges(sections);

    return (
        <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
            <Header />
            <div className="compare-page" style={{ flex: 1 }}>
                <div className="page">
                    {phase === 'loading' && <LoadingOverlay status={loadStatus} />}

                    {phase === 'error' && (
                        <div className="error-bar">{errorMsg}</div>
                    )}

                    {phase === 'done' && (
                        <>
                            <DiffHeader
                                originalFile={originalFile}
                                modifiedFile={modifiedFile}
                                counts={counts}
                                onExport={handleExport}
                            />
                            <div id="diffRoot">
                                {sections.length === 0
                                    ? <div className="empty-hint" style={{ padding: 32, textAlign: 'center' }}>Không có thay đổi nào.</div>
                                    : sections.map((section, i) => (
                                        <DiffSection key={i} section={section} />
                                    ))
                                }
                            </div>
                        </>
                    )}
                </div>
            </div>
            <Footer />
        </div>
    );
}