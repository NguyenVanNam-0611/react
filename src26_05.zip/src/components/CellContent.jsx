// ─────────────────────────────────────────────────────────────
// CellContent.jsx
// ─────────────────────────────────────────────────────────────
import { WordDiff, ImgBox } from './WordDiff';
import { getCellText } from '../utils/diffHelpers';

// ── NestedTable (plain) ───────────────────────────────────────
// Import lazy để tránh circular — FullTable → CellNode → NestedTable → FullTable
import { NestedTable } from './NestedTable';
import { NestedTableWithDiff } from './NestedTable';

// ── CellNode — render LogicalCell không diff ──────────────────
export function CellNode({ cell, cellNode, fallbackText = '' }) {
    const node = cell ?? cellNode;
    if (!node) return <>{fallbackText}</>;

    const { paragraphs = [], images = [], nested_table } = node;

    if (nested_table) {
        return (
            <div>
                {paragraphs.map(p => {
                    const txt = p.text_display || p.text || '';
                    return txt ? <div key={p.uid}>{txt}</div> : null;
                })}
                <NestedTable table={nested_table} />
            </div>
        );
    }

    if (paragraphs.length) {
        return (
            <>
                {paragraphs.map(p => {
                    const txt = p.text_display || p.text || '';
                    const imgs = p.images || [];
                    return (
                        <div key={p.uid}>
                            {txt && <span>{txt}</span>}
                            {imgs.map((img, i) =>
                                img.image_url
                                    ? <ImgBox key={i} url={img.image_url} style={{ marginTop: 4 }} />
                                    : null
                            )}
                        </div>
                    );
                })}
                {images.map((url, i) =>
                    url ? <ImgBox key={`ci-${i}`} url={url} style={{ marginTop: 4 }} /> : null
                )}
            </>
        );
    }

    const txt = node.text_display || node.text || fallbackText;
    return (
        <>
            {txt && <span>{txt}</span>}
            {images.map((url, i) =>
                url ? <ImgBox key={i} url={url} style={{ marginTop: 4 }} /> : null
            )}
        </>
    );
}

// ── Render 1 ParagraphPayload theo side ───────────────────────
function ParagraphNode({ para, side, changeType }) {
    if (!para) return null;
    const txt = para.text_display || para.text || '';
    const imgs = para.images || [];

    const cls =
        changeType === 'insert' ? 'ins-span' :
            changeType === 'delete' ? 'del-span' : '';

    return (
        <div>
            {txt && (cls
                ? <span className={cls}>{txt}</span>
                : <span>{txt}</span>
            )}
            {imgs.map((img, i) =>
                img.image_url
                    ? <ImgBox key={i} url={img.image_url} style={{ marginTop: 4 }} />
                    : null
            )}
        </div>
    );
}

// ── CellContent — render LogicalCell CÓ diff ─────────────────
export function CellContent({ cellChange, side, cell = null, cellNode = null, fallback = '' }) {
    const node = cell ?? cellNode;
    if (!cellChange) {
        return <CellNode cell={node} fallbackText={fallback || getCellText(node)} />;
    }

    const changes = cellChange.changes || [];

    // span_changed: tìm paragraph_modified đầu tiên
    if (cellChange.type === 'table_cell_span_changed') {
        for (const ch of changes) {
            if (ch.type === 'paragraph_modified') {
                return <WordDiff wd={ch} side={side} />;
            }
        }
        const txt = side === 'left'
            ? (cellChange.left_text || '')
            : (cellChange.right_text || '');
        return <>{txt}</>;
    }

    const parts = [];

    for (const ch of changes) {
        const t = ch.type || '';

        // ── paragraph_modified ────────────────────────────────
        if (t === 'paragraph_modified') {
            const paraNode = side === 'left' ? ch.original : ch.modified;
            parts.push(
                <div key={parts.length}>
                    <WordDiff wd={ch} side={side} />
                    {(paraNode?.images || []).map((img, i) =>
                        img.image_url
                            ? <ImgBox key={i} url={img.image_url} style={{ marginTop: 4 }} />
                            : null
                    )}
                </div>
            );
            continue;
        }

        // ── paragraph_unchanged ───────────────────────────────
        if (t === 'paragraph_unchanged') {
            const para = side === 'left' ? ch.original : ch.modified;
            parts.push(<ParagraphNode key={parts.length} para={para} side={side} />);
            continue;
        }

        // ── paragraph_inserted ────────────────────────────────
        if (t === 'paragraph_inserted') {
            if (side === 'right') {
                parts.push(
                    <ParagraphNode key={parts.length} para={ch.modified} side={side} changeType="insert" />
                );
            }
            continue;
        }

        // ── paragraph_deleted ─────────────────────────────────
        if (t === 'paragraph_deleted') {
            if (side === 'left') {
                parts.push(
                    <ParagraphNode key={parts.length} para={ch.original} side={side} changeType="delete" />
                );
            }
            continue;
        }

        // ── image_unchanged ───────────────────────────────────
        if (t === 'image_unchanged') {
            const img = side === 'left' ? ch.original : ch.modified;
            if (img?.image_url) {
                parts.push(
                    <ImgBox key={parts.length} url={img.image_url} style={{ marginTop: 4 }} />
                );
            }
            continue;
        }

        // ── image_modified ────────────────────────────────────
        if (t === 'image_modified') {
            const img = side === 'left' ? ch.original : ch.modified;
            if (img?.image_url) {
                parts.push(
                    <div key={parts.length} className={side === 'left' ? 'del-span' : 'ins-span'}>
                        <ImgBox url={img.image_url} style={{ marginTop: 4 }} />
                    </div>
                );
            }
            continue;
        }

        // ── image_added ───────────────────────────────────────
        if (t === 'image_added' && side === 'right') {
            const img = ch.modified;
            if (img?.image_url) {
                parts.push(
                    <div key={parts.length} className="ins-span">
                        <ImgBox url={img.image_url} style={{ marginTop: 4 }} />
                    </div>
                );
            }
            continue;
        }

        // ── image_deleted ─────────────────────────────────────
        if (t === 'image_deleted' && side === 'left') {
            const img = ch.original;
            if (img?.image_url) {
                parts.push(
                    <div key={parts.length} className="del-span">
                        <ImgBox url={img.image_url} style={{ marginTop: 4 }} />
                    </div>
                );
            }
            continue;
        }

        // ── nested_table_unchanged ────────────────────────────
        if (t === 'nested_table_unchanged') {
            const tbl = side === 'left' ? ch.original : ch.modified;
            parts.push(
                <div key={parts.length}>
                    <span className="nested-tbl-badge eq-badge">= Nested table</span>
                    <NestedTable table={tbl} wrapClass="nested-eq" />
                </div>
            );
            continue;
        }

        // ── nested_table_modified ─────────────────────────────
        if (t === 'nested_table_modified') {
            parts.push(
                <div key={parts.length}>
                    <span className="nested-tbl-badge mod-badge">≈ Nested table (sửa)</span>
                    <NestedTableWithDiff nestedChange={ch} side={side} />
                </div>
            );
            continue;
        }

        // ── nested_table_to_text ──────────────────────────────
        if (t === 'nested_table_to_text') {
            if (side === 'left') {
                parts.push(
                    <div key={parts.length}>
                        <span className="nested-tbl-badge del-badge">- Nested table</span>
                        <NestedTable table={ch.original_table} wrapClass="nested-del" />
                    </div>
                );
            } else {
                const txt = ch.new_text || '';
                if (txt) parts.push(<div key={parts.length}><span className="ins-span">{txt}</span></div>);
            }
            continue;
        }

        // ── text_to_nested_table ──────────────────────────────
        if (t === 'text_to_nested_table') {
            if (side === 'left') {
                const txt = ch.old_text || '';
                if (txt) parts.push(<div key={parts.length}><span className="del-span">{txt}</span></div>);
            } else {
                parts.push(
                    <div key={parts.length}>
                        <span className="nested-tbl-badge ins-badge">+ Nested table</span>
                        <NestedTable table={ch.modified_table} wrapClass="nested-ins" />
                    </div>
                );
            }
            continue;
        }
    }

    if (!parts.length) {
        return <CellNode cell={node} fallbackText={fallback || getCellText(node)} />;
    }
    return <>{parts}</>;
}
