// ─────────────────────────────────────────────────────────────
// TextChange.jsx  (thay thế TextChangeRow inline trong DiffSection)
//
// Fix:
//  1. insert/delete render WordDiff thay vì plain text
//  2. Cả hai cột đều có MetaRow → height đồng đều
//  3. NumberingBadge hiện khi format_changes.numbering.changed = true
// ─────────────────────────────────────────────────────────────
import { WordDiff, MetaRow, EmptyHint, NumberingBadge } from '../WordDiff';

export function TextChangeRow({ change }) {
    const kind = change.change_kind || 'replace';
    const wd = change.word_diff || {};
    const fc = change.format_changes || wd.format_changes || {};

    // ── DELETE ────────────────────────────────────────────────
    if (kind === 'delete') {
        // Dùng WordDiff nếu có spans, fallback plain text
        const hasSpans = Array.isArray(wd.spans) && wd.spans.length > 0;
        const plainTxt = change.left?.preview_text
            || change.left?.node?.content?.text
            || '';

        return (
            <div className={`change-row kind-${kind}`}>
                <div className="change-cell left">
                    <MetaRow change={change} />
                    <NumberingBadge formatChanges={fc} />
                    <div className="txt">
                        {hasSpans
                            ? <WordDiff wd={wd} side="left" />
                            : plainTxt || <EmptyHint>(trống)</EmptyHint>
                        }
                    </div>
                </div>
                <div className="change-cell right">
                    {/* MetaRow ở cả hai phía để giữ layout cao bằng nhau */}
                    <MetaRow change={change} />
                    <EmptyHint style={{ padding: 8 }}>(đã xóa)</EmptyHint>
                </div>
            </div>
        );
    }

    // ── INSERT ────────────────────────────────────────────────
    if (kind === 'insert') {
        const hasSpans = Array.isArray(wd.spans) && wd.spans.length > 0;
        const plainTxt = change.right?.preview_text
            || change.right?.node?.content?.text
            || '';

        return (
            <div className={`change-row kind-${kind}`}>
                <div className="change-cell left">
                    <MetaRow change={change} />
                    <EmptyHint style={{ padding: 8 }}>(chưa tồn tại)</EmptyHint>
                </div>
                <div className="change-cell right">
                    <MetaRow change={change} />
                    <NumberingBadge formatChanges={fc} />
                    <div className="txt">
                        {hasSpans
                            ? <WordDiff wd={wd} side="right" />
                            : plainTxt || <EmptyHint>(trống)</EmptyHint>
                        }
                    </div>
                </div>
            </div>
        );
    }

    // ── REPLACE (modified) ────────────────────────────────────
    return (
        <div className={`change-row kind-${kind}`}>
            <div className="change-cell left">
                <MetaRow change={change} />
                <NumberingBadge formatChanges={fc} />
                <div className="txt"><WordDiff wd={wd} side="left" /></div>
            </div>
            <div className="change-cell right">
                <MetaRow change={change} />
                <NumberingBadge formatChanges={fc} />
                <div className="txt"><WordDiff wd={wd} side="right" /></div>
            </div>
        </div>
    );
}