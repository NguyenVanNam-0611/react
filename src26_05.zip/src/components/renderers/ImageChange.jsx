// ─────────────────────────────────────────────────────────────
// renderers/ImageChange.jsx
// ─────────────────────────────────────────────────────────────
import { MetaRow } from '../WordDiff';

export function ImageChange({ change }) {
    const imgChange = change.image_change || {};
    const leftImg = change.left_img || imgChange.left_img || change.left || null;
    const rightImg = change.right_img || imgChange.right_img || change.right || null;
    const kind = change.change_kind || 'replace';

    const leftUrl = leftImg?.image_url || leftImg?.image?.image_url || null;
    const rightUrl = rightImg?.image_url || rightImg?.image?.image_url || null;

    // Alt text từ backend, fallback tên file
    const leftAlt = leftImg?.image?.name || leftImg?.caption || 'ảnh gốc';
    const rightAlt = rightImg?.image?.name || rightImg?.caption || 'ảnh mới';

    // Fallback text rõ ràng theo từng tình huống
    const leftFallback = kind === 'insert'
        ? '(chưa tồn tại)'
        : '(không tải được ảnh)';

    const rightFallback = kind === 'delete'
        ? '(đã xóa)'
        : '(không tải được ảnh)';

    return (
        <>
            <div className="change-cell left">
                <MetaRow change={change} />
                <ImgSlot url={leftUrl} alt={leftAlt} fallback={leftFallback} />
            </div>
            <div className="change-cell right">
                <MetaRow change={change} />
                <ImgSlot url={rightUrl} alt={rightAlt} fallback={rightFallback} />
            </div>
        </>
    );
}

// ── ImgSlot ───────────────────────────────────────────────────
// Render ảnh hoặc fallback text. max-width/height tránh phá layout.
function ImgSlot({ url, alt, fallback }) {
    if (!url) {
        return (
            <div className="img-box">
                <div className="img-none">{fallback}</div>
            </div>
        );
    }

    return (
        <div className="img-box">
            <img
                src={url}
                alt={alt}
                style={{ maxWidth: '100%', maxHeight: 480, objectFit: 'contain', display: 'block' }}
                onError={e => {
                    // Ảnh load lỗi (URL hết hạn / file bị xóa) → hiện fallback text
                    e.currentTarget.style.display = 'none';
                    e.currentTarget.nextSibling && (e.currentTarget.nextSibling.style.display = 'block');
                }}
            />
            <div className="img-none" style={{ display: 'none' }}>(không tải được ảnh)</div>
        </div>
    );
}