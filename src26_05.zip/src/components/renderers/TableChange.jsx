// ─────────────────────────────────────────────────────────────
// TableChange.jsx  — rewrite toàn bộ
// ─────────────────────────────────────────────────────────────
import { FullTable } from '../FullTable';
import { CellContent, CellNode } from '../CellContent';

// ── RowModifiedView ───────────────────────────────────────────
function RowModifiedView({ tableChanges }) {
    if (!tableChanges.length) return null;

    return (
        <div className="sub-rows-wrap">
            {tableChanges.map((rc, idx) => {
                const type = rc.type || '';
                let L = null, R = null;

                if (type === 'table_row_modified') {
                    const lCells = rc.left_cells || [];
                    const rCells = rc.right_cells || [];

                    const ccMap = {};
                    const delCols = new Set();
                    const addCols = new Set();

                    (rc.cell_changes || []).forEach(cc => {
                        const ac = cc.anchor_col;
                        if (['table_cell_modified', 'table_cell_span_changed'].includes(cc.type))
                            ccMap[ac] = cc;
                        else if (cc.type === 'table_cell_deleted') delCols.add(ac);
                        else if (cc.type === 'table_cell_added') addCols.add(ac);
                    });

                    const renderCells = (cells, side) => cells.map(c => {
                        const ac = c.anchor_col;
                        const cc = ccMap[ac];
                        const cls =
                            cc ? 'cell-changed' :
                                (side === 'left' && delCols.has(ac)) ? 'cell-deleted' :
                                    (side === 'right' && addCols.has(ac)) ? 'cell-added' : '';

                        const cSpan = c.col_span > 1 ? c.col_span : undefined;
                        const rSpan = c.row_span > 1 ? c.row_span : undefined;

                        return (
                            <td key={ac} className={cls} colSpan={cSpan} rowSpan={rSpan}>
                                {cc
                                    ? <CellContent
                                        cellChange={cc}
                                        side={side}
                                        cell={side === 'left' ? cc.left_cell : cc.right_cell}
                                    />
                                    : <CellNode cell={c} />
                                }
                            </td>
                        );
                    });

                    L = (
                        <>
                            <div className="tbl-label" style={{ color: '#b45309' }}>≈ Dòng sửa (gốc)</div>
                            <div className="tbl-wrap">
                                <table className="doc-table">
                                    <tbody><tr>{renderCells(lCells, 'left')}</tr></tbody>
                                </table>
                            </div>
                        </>
                    );
                    R = (
                        <>
                            <div className="tbl-label" style={{ color: '#16a34a' }}>≈ Dòng sửa (mới)</div>
                            <div className="tbl-wrap">
                                <table className="doc-table">
                                    <tbody><tr>{renderCells(rCells, 'right')}</tr></tbody>
                                </table>
                            </div>
                        </>
                    );
                }

                else if (type === 'table_row_added') {
                    const cells = rc.right_cells || [];
                    R = (
                        <>
                            <div className="tbl-label" style={{ color: '#16a34a' }}>+ Dòng mới</div>
                            <div className="tbl-wrap">
                                <table className="doc-table">
                                    <tbody>
                                        <tr className="row-added">
                                            {cells.map(c => (
                                                <td key={c.anchor_col}
                                                    colSpan={c.col_span > 1 ? c.col_span : undefined}
                                                    rowSpan={c.row_span > 1 ? c.row_span : undefined}>
                                                    <CellNode cell={c} />
                                                </td>
                                            ))}
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </>
                    );
                }

                else if (type === 'table_row_deleted') {
                    const cells = rc.left_cells || [];
                    L = (
                        <>
                            <div className="tbl-label" style={{ color: '#dc2626' }}>- Dòng xóa</div>
                            <div className="tbl-wrap">
                                <table className="doc-table">
                                    <tbody>
                                        <tr className="row-deleted">
                                            {cells.map(c => (
                                                <td key={c.anchor_col}
                                                    colSpan={c.col_span > 1 ? c.col_span : undefined}
                                                    rowSpan={c.row_span > 1 ? c.row_span : undefined}>
                                                    <CellNode cell={c} />
                                                </td>
                                            ))}
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </>
                    );
                }

                return (
                    <div key={idx} className="sub-row">
                        <div className="sub-cell sub-left">{L}</div>
                        <div className="sub-cell">{R}</div>
                    </div>
                );
            })}
        </div>
    );
}

// ── Main export ───────────────────────────────────────────────
export function TableChange({ change }) {
    const analysis = change.table_analysis || {};
    const tableChanges = analysis.table_changes || [];
    const renderMode = analysis.render_mode || 'full_table';
    const kind = change.change_kind || 'replace';
    const structChanged = !!analysis.structure_changed;

    const leftTableData = analysis.full_table_original ?? null;
    const rightTableData = analysis.full_table_modified ?? null;

    // ── Deleted ───────────────────────────────────────────────
    if (kind === 'delete' || renderMode === 'table_deleted') {
        return (
            <>
                <div className="change-cell left">
                    <div className="meta-spacer" />
                    <div className="tbl-side-wrap">
                        <FullTable tableData={leftTableData} label="before" />
                    </div>
                </div>
                <div className="change-cell right">
                    <div className="meta-spacer" />
                    <div className="empty-hint" style={{ padding: 10 }}>(đã xóa)</div>
                </div>
            </>
        );
    }

    // ── Inserted ──────────────────────────────────────────────
    if (kind === 'insert') {
        return (
            <>
                <div className="change-cell left">
                    <div className="meta-spacer" />
                    <div className="empty-hint" style={{ padding: 10 }}>(chưa tồn tại)</div>
                </div>
                <div className="change-cell right">
                    <div className="meta-spacer" />
                    <div className="tbl-side-wrap">
                        <FullTable tableData={rightTableData} label="after" />
                    </div>
                </div>
            </>
        );
    }

    // ── Full table side-by-side ───────────────────────────────
    if (renderMode === 'full_table') {
        return (
            <>
                <div className="change-cell left">
                    <div className="meta-spacer" />
                    <div className="tbl-side-wrap">
                        <FullTable
                            tableData={leftTableData}
                            label="before"
                            tableChanges={tableChanges}
                            structureChanged={structChanged}
                        />
                    </div>
                </div>
                <div className="change-cell right">
                    <div className="meta-spacer" />
                    <div className="tbl-side-wrap">
                        <FullTable
                            tableData={rightTableData}
                            label="after"
                            tableChanges={tableChanges}
                            structureChanged={structChanged}
                        />
                    </div>
                </div>
            </>
        );
    }

    // ── Row modified ──────────────────────────────────────────
    return (
        <div style={{ display: 'block', width: '100%' }}>
            <RowModifiedView tableChanges={tableChanges} />
        </div>
    );
}