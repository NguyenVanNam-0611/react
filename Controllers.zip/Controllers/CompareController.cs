﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Diff_tool.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class CompareController : ControllerBase
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _config;

        public CompareController(IHttpClientFactory httpClientFactory, IConfiguration config)
        {
            _httpClientFactory = httpClientFactory;
            _config = config;
        }

        [HttpGet("status/{jobId}")]
        public async Task<IActionResult> GetStatus(string jobId)
        {
            var fastApiUrl = _config["FastApi:BaseUrl"] ?? "http://localhost:8000";
            var client = _httpClientFactory.CreateClient();
            var response = await client.GetAsync($"{fastApiUrl}/api/status/job/{jobId}");
            var content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                return StatusCode((int)response.StatusCode, new { message = content });

            return Content(content, "application/json");
        }
    }
}