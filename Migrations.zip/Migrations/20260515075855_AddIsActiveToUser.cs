﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Diff_tool.Migrations
{
    /// <inheritdoc />
    public partial class AddIsActiveToUser : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                column: "PasswordHash",
                value: "$2a$11$At/ubTTzBztMROH2QGw7R.xX68.BH3zPGmovdmm7vd1W6qmhQghAe");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                column: "PasswordHash",
                value: "$2a$11$1wGzKAMgiFNLGuUgpygKV.xSP22YN31ocZboaLqQmHKs7I1dWm4KC");
        }
    }
}
