// ─────────────────────────────────────────────────────────────
// renderers/ShapeChange.jsx
// ─────────────────────────────────────────────────────────────
import { WordDiff, ImgBox } from '../WordDiff';

function ShapeLines({ lines = [], lineClass = 'line-equal' }) {
    if (!lines.length) return null;
    return (
        <div className="shape-lines">
            {lines.map((l, i) => (
                <div key={i} className={`shape-line ${lineClass}`}>{l}</div>
            ))}
        </div>
    );
}

function ShapeEmpty({ text }) {
    return <div className="empty-hint" style={{ padding: 8 }}>{text}</div>;
}

function ShapeParaImgs({ paraNode }) {
    if (!paraNode) return null;
    const imgs = (paraNode.children || [])
        .filter(ch => ch?.type === 'image')
        .map(ch => ch.image_url || ch.image?.image_url || ch.content?.image_url || null)
        .filter(Boolean);
    if (!imgs.length) return null;
    return (
        <>
            {imgs.map((url, i) => <ImgBox key={i} url={url} style={{ marginTop: 4 }} />)}
        </>
    );
}

// ── Image URL helper — theo structure của image_diff.py ───────
function imgUrl(payload) {
    return payload?.image_url || payload?.image?.image_url || null;
}
// ── Render 1 ảnh trong shape ──────────────────────────────────
function ShapeImgLine({ url, lineClass }) {
    if (!url) return null;
    return (
        <div className={`shape-line ${lineClass}`} style={{ padding: '4px 0' }}>
            <ImgBox url={url} style={{ maxWidth: '100%' }} />
        </div>
    );
}

export function ShapeChange({ change }) {
    const kind = change.change_kind || 'replace';
    const shapeChanges = change.shape_changes || [];

    // ── Insert ────────────────────────────────────────────────
    if (kind === 'insert') {
        const lines = (change.right?.shape_text_lines || []).filter(l => !l.startsWith('['));
        const imgs = change.right?.shape_images || [];
        return (
            <>
                <div className="change-cell left">
                    <div className="meta-spacer" />
                    <ShapeEmpty text="(chưa tồn tại)" />
                </div>
                <div className="change-cell right">
                    <div className="meta-spacer" />
                    {lines.length > 0 && <ShapeLines lines={lines} lineClass="line-ins" />}
                    {imgs.map((img, i) => (
                        <ShapeImgLine key={i} url={img.image_url} lineClass="line-ins" />
                    ))}
                    {!lines.length && !imgs.length && <ShapeEmpty text="(shape trống)" />}
                </div>
            </>
        );
    }

    // ── Delete ────────────────────────────────────────────────
    if (kind === 'delete') {
        const lines = (change.left?.shape_text_lines || []).filter(l => !l.startsWith('['));
        const imgs = change.left?.shape_images || [];
        return (
            <>
                <div className="change-cell left">
                    <div className="meta-spacer" />
                    {lines.length > 0 && <ShapeLines lines={lines} lineClass="line-del" />}
                    {imgs.map((img, i) => (
                        <ShapeImgLine key={i} url={img.image_url} lineClass="line-del" />
                    ))}
                    {!lines.length && !imgs.length && <ShapeEmpty text="(shape trống)" />}
                </div>
                <div className="change-cell right">
                    <div className="meta-spacer" />
                    <ShapeEmpty text="(đã xóa)" />
                </div>
            </>
        );
    }

    // ── Cleared ───────────────────────────────────────────────
    if (change.shape_cleared) {
        const lines = change.left?.shape_text_lines || change.shape_text_preview || [];
        return (
            <>
                <div className="change-cell left">
                    <div className="meta-spacer" />
                    {lines.length
                        ? <ShapeLines lines={lines} lineClass="line-del" />
                        : <ShapeEmpty text="(trống)" />
                    }
                    <div className="shape-cleared-note">★ Toàn bộ nội dung đã bị xóa</div>
                </div>
                <div className="change-cell right">
                    <div className="meta-spacer" />
                    <ShapeEmpty text="(shape đã được xóa nội dung)" />
                </div>
            </>
        );
    }

    // ── No specific changes (equal preview) ──────────────────
    if (!shapeChanges.length) {
        const lines = change.left?.shape_text_lines || [];
        const content = lines.length
            ? <ShapeLines lines={lines} lineClass="line-equal" />
            : <ShapeEmpty text="(trống)" />;
        return (
            <>
                <div className="change-cell left"><div className="meta-spacer" />{content}</div>
                <div className="change-cell right"><div className="meta-spacer" />{content}</div>
            </>
        );
    }

    // ── Render per-change lines ───────────────────────────────
    const leftItems = [];
    const rightItems = [];

    shapeChanges.forEach((sc, idx) => {
        const scType = sc.type || '';
        const orig = sc.original;
        const mod = sc.modified;
        const origText = orig?.content?.text || orig?.text || '';
        const modText = mod?.content?.text || mod?.text || '';

        // ── paragraph_equal ──────────────────────────────────────
        if (scType === 'paragraph_equal') {
            leftItems.push(
                <div key={`L${idx}`} className="shape-line line-equal">
                    {origText}
                    <ShapeParaImgs paraNode={orig} />
                </div>
            );
            rightItems.push(
                <div key={`R${idx}`} className="shape-line line-equal">
                    {modText || origText}
                    <ShapeParaImgs paraNode={mod} />
                </div>
            );

            // ── paragraph_deleted ────────────────────────────────────
        } else if (scType === 'paragraph_deleted') {
            leftItems.push(
                <div key={`L${idx}`} className="shape-line line-del">
                    {origText}
                    <ShapeParaImgs paraNode={orig} />
                </div>
            );

            // ── paragraph_inserted ───────────────────────────────────
        } else if (scType === 'paragraph_inserted') {
            rightItems.push(
                <div key={`R${idx}`} className="shape-line line-ins">
                    {modText}
                    <ShapeParaImgs paraNode={mod} />
                </div>
            );

            // ── paragraph_modified ───────────────────────────────────
        } else if (scType === 'paragraph_modified') {
            const wd = sc.word_diff || {};
            leftItems.push(
                <div key={`L${idx}`} className="shape-line line-modified">
                    <WordDiff wd={wd} side="left" />
                    <ShapeParaImgs paraNode={orig} />
                </div>
            );
            rightItems.push(
                <div key={`R${idx}`} className="shape-line line-modified">
                    <WordDiff wd={wd} side="right" />
                    <ShapeParaImgs paraNode={mod} />
                </div>
            );

            // ── image_equal ──────────────────────────────────────────
        } else if (scType === 'image_equal') {
            const url = imgUrl(sc.left) || imgUrl(sc.right);
            leftItems.push(<ShapeImgLine key={`L${idx}`} url={url} lineClass="line-equal" />);
            rightItems.push(<ShapeImgLine key={`R${idx}`} url={url} lineClass="line-equal" />);

            // ── image_modified ───────────────────────────────────────
        } else if (scType === 'image_modified') {
            leftItems.push(<ShapeImgLine key={`L${idx}`} url={imgUrl(sc.left)} lineClass="line-del" />);
            rightItems.push(<ShapeImgLine key={`R${idx}`} url={imgUrl(sc.right)} lineClass="line-ins" />);

            // ── image_added ──────────────────────────────────────────
        } else if (scType === 'image_added') {
            rightItems.push(<ShapeImgLine key={`R${idx}`} url={imgUrl(sc.right)} lineClass="line-ins" />);

            // ── image_deleted ────────────────────────────────────────
        } else if (scType === 'image_deleted') {
            leftItems.push(<ShapeImgLine key={`L${idx}`} url={imgUrl(sc.left)} lineClass="line-del" />);
        }
    });

    return (
        <>
            <div className="change-cell left">
                <div className="meta-spacer" />
                {leftItems.length
                    ? <div className="shape-lines">{leftItems}</div>
                    : <ShapeEmpty text="—" />
                }
            </div>
            <div className="change-cell right">
                <div className="meta-spacer" />
                {rightItems.length
                    ? <div className="shape-lines">{rightItems}</div>
                    : <ShapeEmpty text="—" />
                }
            </div>
        </>
    );
}